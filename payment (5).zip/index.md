| seq | method | status | mime | size | url |
|---:|:--|:--:|:--|--:|:--|
| 4 | GET | 304 | text/javascript | 811 | https://snap-assets.al-pc-id-p.cdn.gtflabs.io/snap/v4/assets/snap-redirection-app.production.fb6cf3fda9a8a1a54174.js |
| 9 | GET | 200 | text/javascript | 0 | https://snap-assets.al-pc-id-p.cdn.gtflabs.io/snap/newrelic-assets/nr-spa.production.min.js |
| 10 | GET | 200 | application/json | 1656 | https://app.midtrans.com/snap/v1/transactions/79bd72b3-1ffe-405d-968d-8693e9b5aa5c |
| 11 | POST | 200 | application/json | 505 | https://app.midtrans.com/snap/v1/promos/79bd72b3-1ffe-405d-968d-8693e9b5aa5c/search |
| 12 | GET | 200 | application/json | 358 | https://app.midtrans.com/snap/v3/experiment?id=79bd72b3-1ffe-405d-968d-8693e9b5aa5c |
| 13 | GET | 0 |  | 0 | https://js-agent.newrelic.com/nr-spa-1.288.1.min.js |
| 14 | POST | 200 | application/proto | 99 | https://snap-web-raccoon.gojekapi.com/api/v1/events |
| 17 | GET | 0 |  | 0 | https://js-agent.newrelic.com/nr-spa-1.288.1.min.js |
| 18 | POST | 202 | text/plain | 40 | https://global.faro.katulampa.gopay.sh/collect |
| 20 | POST | 200 | application/proto | 99 | https://snap-web-raccoon.gojekapi.com/api/v1/events |
| 29 | POST | 202 | text/plain | 63 | https://global.faro.katulampa.gopay.sh/collect |
| 30 | POST | 202 | text/plain | 40 | https://global.faro.katulampa.gopay.sh/collect |
| 39 | GET | 200 | application/json | 519 | https://api.midtrans.com/v1/bins/52172930 |
| 43 | POST | 202 | text/plain | 40 | https://global.faro.katulampa.gopay.sh/collect |
| 45 | POST | 200 | application/proto | 96 | https://snap-web-raccoon.gojekapi.com/api/v1/events |
| 47 | POST | 202 | text/plain | 63 | https://global.faro.katulampa.gopay.sh/collect |
| 48 | POST | 200 | application/proto | 96 | https://snap-web-raccoon.gojekapi.com/api/v1/events |
| 50 | POST | 200 | application/json | 419 | https://api.midtrans.com/v2/token |
| 55 | POST | 202 | text/plain | 43 | https://global.faro.katulampa.gopay.sh/collect |
| 56 | POST | 200 | application/proto | 119 | https://snap-web-raccoon.gojekapi.com/api/v1/events |
| 57 | POST | 200 | application/json | 748 | https://app.midtrans.com/snap/v2/transactions/79bd72b3-1ffe-405d-968d-8693e9b5aa5c/charge |
| 58 | POST | 202 | text/plain | 63 | https://global.faro.katulampa.gopay.sh/collect |
| 59 | POST | 200 | application/proto | 96 | https://snap-web-raccoon.gojekapi.com/api/v1/events |
| 61 | POST | 200 | application/proto | 100 | https://snap-web-raccoon.gojekapi.com/api/v1/events |
| 62 | POST | 202 | text/plain | 40 | https://global.faro.katulampa.gopay.sh/collect |
| 66 | GET | 0 |  | 0 | https://www.securesuite.co.uk/3ds2/js/dfp.js |
| 67 | GET | 200 | text/javascript | 4828 | https://www.securesuite.co.uk/3ds2/js/wasm_fingerprint.js |
| 68 | GET | 200 | application/wasm | 41952 | https://www.securesuite.co.uk/3ds2/js/wasm_fingerprint_bg.wasm |
| 69 | GET | 200 | image/gif | 431 | https://www.securesuite.co.uk/3ds2/js/loading.gif |
| 71 | POST | 202 | text/plain | 40 | https://global.faro.katulampa.gopay.sh/collect |
| 82 | GET | 200 | application/json | 955 | https://app.midtrans.com/snap/v1/transactions/79bd72b3-1ffe-405d-968d-8693e9b5aa5c/status |
| 83 | POST | 200 | application/proto | 96 | https://snap-web-raccoon.gojekapi.com/api/v1/events |
| 87 | POST | 202 | text/plain | 63 | https://global.faro.katulampa.gopay.sh/collect |
| 89 | POST | 200 | application/proto | 119 | https://snap-web-raccoon.gojekapi.com/api/v1/events |
| 90 | POST | 200 | application/proto | 96 | https://snap-web-raccoon.gojekapi.com/api/v1/events |
| 91 | POST | 202 | text/plain | 40 | https://global.faro.katulampa.gopay.sh/collect |
| 93 | POST | 200 | application/proto | 96 | https://snap-web-raccoon.gojekapi.com/api/v1/events |
| 94 | POST | 202 | text/plain | 40 | https://global.faro.katulampa.gopay.sh/collect |
